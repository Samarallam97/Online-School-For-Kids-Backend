﻿using Domain.Entities.Content.Moderation;
using Domain.Entities.Content.Progress;
using Domain.Entities.Users;
using Domain.Enums.Content;

namespace Domain.Entities.Content
{
    public class Course : BaseEntity
    {
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string InstructorId { get; set; } = string.Empty;
        public string CategoryId { get; set; } = string.Empty;
        public AgeGroup AgeGroup { get; set; }
        public decimal Price { get; set; }
        public decimal? DiscountPrice { get; set; }
        public decimal Rating { get; set; }
        public int TotalStudents { get; set; }
        public int DurationHours { get; set; }
        public string ThumbnailUrl { get; set; } = string.Empty;
        public string Language { get; set; } = "English";
        public bool IsPublished { get; set; }
        public bool IsFeatured { get; set; }
        public bool IsVisible { get; set; } = true;
        public CourseModerationStatus? ModerationStatus { get; set; }

        // ── Metadata fields ──────────────────────────────────────────────
        /// <summary>Short tagline shown under the course title.</summary>
        public string? Subtitle { get; set; }

        /// <summary>Bullet list of learning outcomes ("What you'll learn").</summary>
        public List<string> WhatYoullLearn { get; set; } = new();

        /// <summary>Bullet list of prerequisites.</summary>
        public List<string> Requirements { get; set; } = new();

        /// <summary>Short promotional clip shown before purchase (uploaded, not a lesson).</summary>
        public string? PreviewVideoUrl { get; set; }

        // Navigation Properties
        public Category Category { get; set; } = null!;
        public User Instructor { get; set; } = null!;

        public ICollection<Wishlist> Wishlists { get; set; } = new List<Wishlist>();
        public ICollection<Section>? Sections { get; set; }
    }
}