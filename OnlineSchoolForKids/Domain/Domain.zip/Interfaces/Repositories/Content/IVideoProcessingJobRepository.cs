﻿using Domain.Entities.Content;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces.Repositories.Content;

public interface IVideoProcessingJobRepository : IGenericRepository<VideoProcessingJob>
{
}